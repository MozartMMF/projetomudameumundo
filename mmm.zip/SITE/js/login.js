let btn = document.querySelector('.fa-eye')

btn.addEventListener('click', ()=>{
  let inputSenha = document.querySelector('#senha')
  
  if(inputSenha.getAttribute('type') == 'password'){
    inputSenha.setAttribute('type', 'text')
  } else {
    inputSenha.setAttribute('type', 'password')
  }
})

function entrar(){
  const url = "http://localhost:5500/api"
  let user = document.querySelector('#email')
  let userLabel = document.querySelector('#emailLabel')
  
  let password = document.querySelector('#senha')
  let passwordLabel = document.querySelector('#senhaLabel')
  
  let msgError = document.querySelector('#msgError')
  let listaUser = []
  
  let userValid = {
    nome: '',
    sobrenome: '',
    email: '',
    senha: ''
  }
  function getUser(){
    axios.get(url)
    .then(response => {
      listaUser = response.data.users
      listaUser.forEach((item) => {
        if(user.value == item.emailCad && password.value == item.senhaCad){
          userValid = {
            nome: item.nomeCad,
            sobrenome: item.sobrenomeCad,
            email: item.emailCad,
            senha: item.senhaCad
          }
        }
      })
    })
  }

  
    //listaUsers = JSON.parse(localStorage.getItem('listaUsers'))
  
 
   
  
    console.log(userValid)
    if(user.value == userValid.email && senha.value == userValid.senha){
    window.location.href = 'logado.html'
    
    let mathRandom = Math.random().toString(16).substr(2)
    let token = mathRandom + mathRandom
    
    localStorage.setItem('token', token)
    localStorage.setItem('userLogado', JSON.stringify(userValid))
    } 
    else {
    userLabel.setAttribute('style', 'color: red')
    user.setAttribute('style', 'border-color: red')
    passwordLabel.setAttribute('style', 'color: red')
    password.setAttribute('style', 'border-color: red')
    msgError.setAttribute('style', 'display: block')
    msgError.innerHTML = 'Email ou senha incorretos'
    email.focus()
  }
 getUser()
  function sair(){
    localStorage.removeItem('token')
    window.location.href = 'login.html'
  }

}
 
  
